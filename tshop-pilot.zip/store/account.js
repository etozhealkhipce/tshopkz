export const state = () => ({
  wishlist: []
})

export const mutations = {
  ADD_WISHLIST(state, wishlist) {
    state.wishlist = wishlist
  }
}
export const actions = {
  async fetchWishlist({ commit }) {
    const response = await this.$axios.get('/user/wishlist')
    commit('ADD_WISHLIST', response.data)
  }
}
export const getters = {
  isAuthenticated(state) {
    return state.auth.loggedIn
  },
  loggedInUser(state) {
    return state.auth.user
  }
}
