export const state = () => ({
  isLoading: false
})
export const mutations = {
  EDIT_IS_LOADING(state, value) {
    state.isLoading = value
  }
}
export const actions = {
  editIsLoading({ commit }, value) {
    commit('EDIT_IS_LOADING', value)
  }
}
export const getters = {
  isAuthenticated(state) {
    return state.auth.loggedIn
  },
  loggedInUser(state) {
    return state.auth.user
  }
}
