<template>
  <section class="section">
    <div class="container">
      <div class="catalog">
        <div class="columns is-multiline is-variable is-4">
          <div class="main-title column is-full">
            <h2 class="title is-3 is-uppercase">{{ mainCategory.title }}</h2>
          </div>
          <div v-for="(product, index) in mainCategory.products" :key="`product-${index}`" class="column is-4">
            <nuxt-link :to="`/product/${product.slug}`">
              <div class="card">
                <div class="card-image">
                  <figure class="image is-square">
                    <img :src="product.main_img" alt="Placeholder image" />
                  </figure>
                </div>
                <div class="card-content">
                  <h3 class="title is-5 is-spaced">{{ product.title }}</h3>
                  <p class="subtitle is-5">{{ product.description }}</p>
                </div>
              </div>
            </nuxt-link>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  data() {
    return {
      mainCategory: {
        title: '',
        products: [
          {
            main_img: '',
            title: '',
            description: '',
            slug: ''
          }
        ]
      }
    }
  },
  created() {
    this.fetchMainCategory()
  },
  methods: {
    async fetchMainCategory() {
      const response = await this.$axios.get('/main-page-category')
      this.mainCategory = response.data
    }
  }
}
</script>

<style scoped lang="scss">
.catalog {
  width: 100%;

  .container {
    height: 500px;
  }

  .card-content {
    background-color: #171717;
  }
}
</style>
