<template>
  <main class="main"></main>
</template>

<script>
export default {}
</script>

<style></style>
