<template>
  <client-only>
    <section class="section">
      <div class="container">
        <Login v-if="isRegister === false" @isRegister="isRegister = true" />
        <Register v-else @isRegister="isRegister = false" />
      </div>
    </section>
  </client-only>
</template>

<script>
import Login from '@/components/auth/Login'
import Register from '@/components/auth/Register'

export default {
  middleware: ['auth'],
  auth: 'guest',
  layout: 'empty',
  components: {
    Login,
    Register
  },
  data() {
    return {
      isRegister: false
    }
  },

  methods: {}
}
</script>

<style scoped lang="scss"></style>
